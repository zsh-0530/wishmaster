import 'package:flutter/material.dart';

class WishIcons {
  WishIcons._();

  static const IconData arrowDown = IconData(0xe741, fontFamily: 'wish-icons');

  static const IconData arrowUp = IconData(0xe744, fontFamily: 'wish-icons');

  static const IconData period = IconData(0xe745, fontFamily: 'wish-icons');
}
